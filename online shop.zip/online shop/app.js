const products = [
  {
    id: 1,
    name: "Men's T-Shirt",
    price: 19.99,
    img: "https://images.pexels.com/photos/532220/pexels-photo-532220.jpeg?auto=compress&w=120&h=120",
    category: "men"
  },
  {
    id: 2,
    name: "Women's Dress",
    price: 29.99,
    img: "https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&w=120&h=120",
    category: "women"
  },
  {
    id: 3,
    name: "Men's Jacket",
    price: 49.99,
    img: "https://images.pexels.com/photos/1707828/pexels-photo-1707828.jpeg?auto=compress&w=120&h=120",
    category: "men"
  },
  {
    id: 4,
    name: "Women's Handbag",
    price: 45.99,
    img: "https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&w=120&h=120",
    category: "women"
  },
  {
    id: 5,
    name: "Men's Sneakers",
    price: 35.50,
    img: "https://images.pexels.com/photos/298863/pexels-photo-298863.jpeg?auto=compress&w=120&h=120",
    category: "men"
  },
  {
    id: 6,
    name: "Women's Sandals",
    price: 23.75,
    img: "https://images.pexels.com/photos/1375736/pexels-photo-1375736.jpeg?auto=compress&w=120&h=120",
    category: "women"
  }
];

let cart = [];
let selectedCategory = 'all';

function renderProducts() {
  const productList = document.getElementById('product-list');
  productList.innerHTML = '';
  const filtered = selectedCategory === 'all'
    ? products
    : products.filter(p => p.category === selectedCategory);
  filtered.forEach(product => {
    const div = document.createElement('div');
    div.className = 'product-card';
    div.innerHTML = `
      <img src="${product.img}" alt="${product.name}" />
      <div class="name">${product.name}</div>
      <div class="price">$${product.price.toFixed(2)}</div>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
    `;
    productList.appendChild(div);
  });
}

function filterCategory(cat) {
  selectedCategory = cat;
  renderProducts();
}

function addToCart(id) {
  const prod = products.find(p => p.id === id);
  const cartItem = cart.find(item => item.id === id);
  if (cartItem) {
    cartItem.qty += 1;
  } else {
    cart.push({ ...prod, qty: 1 });
  }
  updateCartCount();
}

function updateCartCount() {
  document.getElementById('cart-count').textContent = cart.reduce((a, c) => a + c.qty, 0);
}

function toggleCart() {
  const modal = document.getElementById('cart-modal');
  if (modal.style.display === 'flex') {
    modal.style.display = 'none';
  } else {
    renderCart();
    modal.style.display = 'flex';
  }
}

function renderCart() {
  const cartItems = document.getElementById('cart-items');
  const cartTotal = document.getElementById('cart-total');
  cartItems.innerHTML = '';
  let total = 0;
  cart.forEach(item => {
    total += item.price * item.qty;
    const li = document.createElement('li');
    li.innerHTML = `
      <span>${item.name} x${item.qty}</span>
      <span>
        $${(item.price * item.qty).toFixed(2)}
        <button onclick="removeFromCart(${item.id})">✕</button>
      </span>
    `;
    cartItems.appendChild(li);
  });
  cartTotal.textContent = total.toFixed(2);
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  updateCartCount();
  renderCart();
}

function checkout() {
  if (cart.length === 0) {
    alert('Your cart is empty!');
    return;
  }
  alert('Checkout successful! Thank you for your purchase.');
  cart = [];
  updateCartCount();
  toggleCart();
}

window.onload = () => {
  renderProducts();
  updateCartCount();
};